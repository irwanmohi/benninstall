#!/bin/bash
clear
accel-cmd show sessions
echo ""
echo "By LostServer"
