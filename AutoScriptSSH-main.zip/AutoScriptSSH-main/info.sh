#!/bin/bash

clear
neofetch
echo -e "by LostServer"